export interface LoadingState {
  analysis: boolean | string | null;
  pattern: boolean | string | null;
  image: boolean | string | null;
  video: boolean | string | null;
}

// FIX: Define the AIStudio interface and augment the global Window object to fix declaration errors.
export interface AIStudio {
  hasSelectedApiKey: () => Promise<boolean>;
  openSelectKey: () => Promise<void>;
}

declare global {
  interface Window {
    aistudio: AIStudio;
  }
}
